public enum ClasePersonaje {
    GUERRERO,
    MAGO,
    ARQUERO
}