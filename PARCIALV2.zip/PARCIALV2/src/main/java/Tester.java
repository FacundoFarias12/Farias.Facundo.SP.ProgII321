import java.io.*; // Para manejo de archivos y excepciones de entrada/salida
import java.util.*; // Para listas, comparadores y colecciones
import java.util.function.*; // Para Predicate, Function, Consumer

public class Tester {
    public static void main(String[] args) {
        try {
            // Crear un inventario de personajes
            Inventario<Personaje> inventario = new Inventario<>();

            // Agregar personajes
            inventario.agregar(new Personaje(1, "Aragorn", ClasePersonaje.GUERRERO, 20));
            inventario.agregar(new Personaje(2, "Gandalf", ClasePersonaje.MAGO, 50));
            inventario.agregar(new Personaje(3, "Legolas", ClasePersonaje.ARQUERO, 25));
            inventario.agregar(new Personaje(4, "Frodo", ClasePersonaje.GUERRERO, 10));
            inventario.agregar(new Personaje(5, "Saruman", ClasePersonaje.MAGO, 40));
            inventario.agregar(new Personaje(6, "Robin Hood", ClasePersonaje.ARQUERO, 30));

            // Mostrar todos los personajes
            System.out.println("Inventario inicial:");
            inventario.paraCadaElemento(System.out::println);

            // Ordenar personajes por nombre (orden natural)
            inventario.ordenar();
            System.out.println("\nOrdenados por nombre:");
            inventario.paraCadaElemento(System.out::println);

            // Ordenar personajes por nivel utilizando un Comparator
            inventario.ordenar((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()));
            System.out.println("\nOrdenados por nivel:");
            inventario.paraCadaElemento(System.out::println);

            // Filtrar personajes de la clase MAGO
            Inventario<Personaje> magos = inventario.filtrar(p -> p.getClase() == ClasePersonaje.MAGO);
            System.out.println("\nPersonajes de clase MAGO:");
            magos.paraCadaElemento(System.out::println);

            // Transformar personajes (aumentar nivel en +5)
            inventario.transformar(p -> {
                p.setNivel(p.getNivel() + 5);
                return p;
            });
            System.out.println("\nNivel de todos los personajes aumentado en +5:");
            inventario.paraCadaElemento(System.out::println);

            // Guardar el inventario en un archivo binario
            inventario.guardarEnArchivo("personajes.dat");

            // Cargar el inventario desde el archivo binario
            Inventario<Personaje> inventarioBinario = new Inventario<>();
            inventarioBinario.cargarDesdeArchivo("personajes.dat");
            System.out.println("\nPersonajes cargados desde archivo binario:");
            inventarioBinario.paraCadaElemento(System.out::println);

            // Guardar el inventario en un archivo CSV
            inventario.guardarEnCSV("personajes.csv");

            // Cargar el inventario desde el archivo CSV
            Inventario<Personaje> inventarioCSV = new Inventario<>();
            inventarioCSV.cargarDesdeCSV("personajes.csv");
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            inventarioCSV.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}