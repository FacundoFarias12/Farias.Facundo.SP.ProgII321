import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, Serializable {
    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    // Constructor
    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    // Getters y Setters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public ClasePersonaje getClase() { return clase; }
    public int getNivel() { return nivel; }

    public void setNivel(int nivel) { this.nivel = nivel; }

    // Método toString
    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Clase: " + clase + ", Nivel: " + nivel;
    }

    // Implementación de Comparable (orden natural: por nombre)
    @Override
    public int compareTo(Personaje otro) {
        return this.nombre.compareTo(otro.nombre);
    }

    // Métodos CSVSerializable
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }

    public static Personaje fromCSV(String lineaCSV) {
        String[] partes = lineaCSV.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        ClasePersonaje clase = ClasePersonaje.valueOf(partes[2]);
        int nivel = Integer.parseInt(partes[3]);
        return new Personaje(id, nombre, clase, nivel);
    }
}