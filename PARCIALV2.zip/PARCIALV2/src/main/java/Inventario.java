import java.io.*;
import java.util.*;
import java.util.function.*;

public class Inventario<T> implements Serializable {
    private List<T> elementos;

    public Inventario() {
        elementos = new ArrayList<>();
    }

    // Agregar un elemento
    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    // Eliminar un elemento
    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    // Listar elementos
    public void paraCadaElemento(Consumer<T> accion) {
        elementos.forEach(accion);
    }

    // Ordenar elementos (por orden natural o usando un Comparator)
    public void ordenar() {
        Collections.sort((List<? extends Comparable>) elementos);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    // Filtrar elementos
    public Inventario<T> filtrar(Predicate<T> criterio) {
        Inventario<T> resultado = new Inventario<>();
        elementos.stream().filter(criterio).forEach(resultado::agregar);
        return resultado;
    }

    // Transformar elementos
    public void transformar(Function<T, T> transformacion) {
        List<T> transformados = new ArrayList<>();
        for (T elemento : elementos) {
            transformados.add(transformacion.apply(elemento));
        }
        elementos = transformados;
    }

    // Guardar en un archivo binario
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    // Cargar desde un archivo binario
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    // Guardar en un archivo CSV
    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                if (elemento instanceof Personaje) {
                    writer.write(((Personaje) elemento).toCSV());
                    writer.newLine();
                }
            }
        }
    }

    // Cargar desde un archivo CSV
    public void cargarDesdeCSV(String ruta) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add((T) Personaje.fromCSV(linea));
            }
        }
    }
}
